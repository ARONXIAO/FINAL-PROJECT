# encoding: utf-8
detail_table = """
CREATE TABLE if not exists detail(
    id integer primary key,
    ancestor_id integer,
    name text,
    preferred_common_name text,
    ancestor text,
    wiki text
);
"""

ancestor_index = """
create index if not exists i_ancestor_id on detail(ancestor_id);
"""

stat_data_table = """
CREATE TABLE if not exists stat_data(
    id integer primary key ,
    popular text,
    season_research text,
    season_verifiable text,
    history_research text,
    history_verifiable text,
    ancestor_id integer,
    foreign key (ancestor_id) references detail(ancestor_id)
);
"""

taxon_table = """
CREATE TABLE if not exists taxon_name(
    id integer primary key ,
    lexicon text,
    name text,
    ancestor_id integer,
    foreign key (ancestor_id) references detail(ancestor_id)
);
"""

location_table = """
CREATE TABLE if not exists location(
    id integer primary key ,
    lat float,
    lng float,
    ancestor_id integer,
    foreign key (ancestor_id) references detail(ancestor_id)
);
"""
