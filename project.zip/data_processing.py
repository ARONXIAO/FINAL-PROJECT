# encoding:utf-8
from tqdm import tqdm

import sqlite3
import json
import os
import sql_case


db_path = os.path.abspath('./birds.db')


if __name__ == '__main__':
    # rebuild database if run this file
    if os.path.isfile(db_path):
        os.remove(db_path)

    db = sqlite3.connect(db_path)
    cur = db.cursor()
    cur.execute(sql_case.detail_table)
    cur.execute(sql_case.ancestor_index)
    cur.execute(sql_case.location_table)
    cur.execute(sql_case.taxon_table)
    cur.execute(sql_case.stat_data_table)
    db.commit()

    ancestor_id_map = {}

    detail_table = []
    detail_files = os.listdir('./cache_data/detail')
    for file in tqdm(detail_files):
        detail = json.load(open(f"./cache_data/detail/{file}", mode='r', encoding='utf-8'))

        ancestor_id = detail.get('id')
        ancestor_id_map[file] = ancestor_id

        name = detail.get('name')
        preferred_common_name = detail.get('preferred_common_name')
        ancestor = detail.get('ancestry')
        wiki = detail.get('wikipedia_url')
        detail_table.append([ancestor_id, name, preferred_common_name, ancestor, wiki])

    cur.executemany('insert into detail values (null, ?, ?, ?, ?, ?)', detail_table)
    db.commit()

    stat_table = []
    taxon_name_table = []
    location_table = []
    stat_files = os.listdir('./cache_data/stat_data')
    for file in tqdm(stat_files):
        ancestor_id = ancestor_id_map.get(file)
        if not ancestor_id:
            continue

        stat_data = json.load(open(f"./cache_data/stat_data/{file}", mode='r', encoding='utf-8'))
        popular = json.loads(stat_data['popular'])
        season_verifiable = json.loads(stat_data['season_verifiable'])
        season_research = json.loads(stat_data['season_research'])
        history_verifiable = json.loads(stat_data['history_verifiable'])
        history_research = json.loads(stat_data['history_research'])
        taxon_name = json.loads(stat_data['taxon_name'])
        location = json.loads(stat_data['location'])

        season_research = [season_research['results']['month_of_year'][str(month)] for month in range(1, 13)]
        season_verifiable = [season_verifiable['results']['month_of_year'][str(month)] for month in range(1, 13)]
        history_research = history_research['results']['month']
        history_verifiable = history_verifiable['results']['month']
        popular = {item['controlled_value']['label']: item['month_of_year'] for item in popular['results']}
        stat_table.append([
            json.dumps(popular),
            json.dumps(season_research), json.dumps(season_verifiable),
            json.dumps(history_research), json.dumps(history_verifiable),
            ancestor_id
        ])

        for item in taxon_name:
            name = item.get('name')
            lexicon = item.get('lexicon')
            taxon_name_table.append([lexicon, name, ancestor_id])

        for item in location['results']:
            if item['location']:
                lat, lng = item['location'].split(',')
                location_table.append([float(lat), float(lng), ancestor_id])

    cur.executemany('insert into stat_data values (null, ?, ?, ?, ?, ?, ?)', stat_table)
    cur.executemany('insert into taxon_name values (null, ?, ?, ?)', taxon_name_table)
    cur.executemany('insert into location values (null, ?, ?, ?)', location_table)
    db.commit()
