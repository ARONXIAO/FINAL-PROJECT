# encoding:utf-8
from datetime import datetime
import json
import re

import requests


def request_get(url: str, byte_: bool = False, **kwargs):
    try:
        req = requests.get(url, **kwargs)
        if req.status_code != 200:
            raise ValueError
        return req.text if not byte_ else req.content
    except Exception as exc:
        print(f"{datetime.now()} - request_get - {repr(exc)} - {url}")
        return None


def bird_list_page(page: int):
    params = {
        'page': page, 'locale': 'en', 'taxon_id': '3', 'swlng': '-124.38999999999999', 'swlat': '25.82',
        'nelng': '-66.94', 'nelat': '49.38', 'spam': 'false', 'verifiable': 'true'
    }
    api = f"https://api.inaturalist.org/v1/observations/species_counts"

    response = request_get(url=api, timeout=5, params=params)
    return response


def bird_list():
    page1 = bird_list_page(page=1)
    if not page1:
        return page1

    page1 = json.loads(page1)
    total = page1.get('results')
    total_num = page1.get('total_results')
    per_page = page1.get('per_page')
    page_num = total_num // per_page + 1 if (total_num % per_page) > 0 else total_num // per_page
    for page in range(2, page_num + 1):
        page_data = bird_list_page(page=page)
        if not page_data:
            continue
        page_data = json.loads(page_data)
        total += page_data.get('results')
    return total


def bird_detail(bird_list_item: dict):
    try:
        bird_id = bird_list_item['taxon']['id']
        bird_name = f"{bird_list_item['taxon']['preferred_common_name']}({bird_list_item['taxon']['name']})"

        detail_html = request_get(f"https://www.inaturalist.org/taxa/{bird_id}", timeout=5)
        if not detail_html:
            return bird_name, None

        detail_info = re.findall('"results":\[([\s\S]*)\]}.results\[0\]', detail_html)
        if not detail_info:
            return bird_name, None
        detail_info = json.loads(detail_info[0])
        return bird_name, detail_info
    except Exception as exc:
        print(f"{datetime.now()} - bird_detail - {repr(exc)}")
        return None, None


def get_photos(bird_name: str, detail_info: dict):
    urls = []
    try:
        urls += [photo.get('photo')['original_url'] for photo in detail_info.get('taxon_photos')]
        for index, url in enumerate(urls):
            pic = request_get(url, byte_=True, timeout=5)
            if not pic:
                continue
            filename = f"./photo/{bird_name}-{index}.jpg"
            with open(filename, mode='ba') as f:
                f.write(pic)
    except Exception as exc:
        print(f'{datetime.now()} - get_photo - {exc}')
    finally:
        return urls


def statistics_data(bird_id: int, bird_name: str, write: bool = True):
    api_popular = f"https://api.inaturalist.org/v1/observations/popular_field_values?taxon_id={bird_id}&per_page=50&verifiable=true"
    api_season_verifiable = f"https://api.inaturalist.org/v1/observations/histogram?verifiable=true&taxon_id={bird_id}&place_id=&preferred_place_id=&locale=en&date_field=observed&interval=month_of_year"
    api_season_research = f"https://api.inaturalist.org/v1/observations/histogram?verifiable=true&taxon_id={bird_id}&place_id=&preferred_place_id=&locale=en&date_field=observed&interval=month_of_year&quality_grade=research"
    api_history_research = f"https://api.inaturalist.org/v1/observations/histogram?verifiable=true&taxon_id={bird_id}&place_id=&preferred_place_id=&locale=en&date_field=observed&interval=month&quality_grade=research"
    api_history_verifiable = f"https://api.inaturalist.org/v1/observations/histogram?verifiable=true&taxon_id={bird_id}&place_id=&preferred_place_id=&locale=en&date_field=observed&interval=month"
    api_taxon_name = f"https://www.inaturalist.org/taxon_names.json?per_page=200&taxon_id={bird_id}"
    api_location = f"https://api.inaturalist.org/v1/observations?verifiable=true&taxon_id={bird_id}&place_id=&preferred_place_id=&locale=en&per_page=200"

    popular = request_get(api_popular, timeout=5)
    season_verifiable = request_get(api_season_verifiable, timeout=5)
    season_research = request_get(api_season_research, timeout=5)
    history_research = request_get(api_history_research, timeout=5)
    history_verifiable = request_get(api_history_verifiable, timeout=5)
    taxon_name = request_get(api_taxon_name, timeout=5)
    location = request_get(api_location, timeout=5)

    if write and all([popular, season_research, season_verifiable, history_research, history_verifiable, taxon_name, location]):
        stat_data = {
            'popular': popular, 'season_verifiable': season_verifiable, 'season_research': season_research,
            'history_verifiable': history_verifiable, 'history_research': history_research, 'taxon_name': taxon_name,
            'location': location
        }
        json.dump(stat_data, open(f"./cache_data/stat_data/{bird_name}.json", mode='a', encoding='utf-8'))
    return popular, season_verifiable, season_research, history_verifiable, history_research, taxon_name, location


if __name__ == '__main__':
    # get birds list, data source: api
    total_birds_list = bird_list()
    json.dump(total_birds_list, open('./cache_data/total_birds_list.json', encoding='utf-8', mode='a'))

    for bird_item in total_birds_list:
        # get detail information, like ancestry, preferred common name and academic name
        # data source: html, the information is in the script tag
        # so, I use regex to extract
        name, detail = bird_detail(bird_item)
        if detail:
            json.dump(detail, open(f'./cache_data/detail/{name}.json', mode='a', encoding='utf-8'))
            # request picture urls in detail
            get_photos(name, detail)
            # request statistics data, data source: api
            statistics_data(detail['id'], name)
