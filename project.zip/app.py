# encoding:utf-8
from dash.dependencies import Input, Output
import dash_html_components as html
import dash_core_components as dcc
import dash

import draw_figure


app = dash.Dash(
    __name__,
    external_stylesheets=[
        'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css',
    ],
    external_scripts=[
        'https://code.jquery.com/jquery-3.4.1.slim.min.js',
        'https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js',
        'https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js',
    ],
    assets_external_path='./photo'
)


app.layout = html.Div(children=[
    html.Div(children=[
        html.Nav(children=[
            html.A('Birds', className="navbar-brand", href='/'),
            html.Div(children=[
                html.Ul(children=[], className="navbar-nav mr-auto")
            ], className="collapse navbar-collapse")
        ], className="navbar navbar-expand-lg navbar-light bg-light")
    ], id='head'),
    html.Div(children=[
        html.H4('Input Bird Name:'),
        dcc.Dropdown(options=draw_figure.birds_list(), value='Acanthis flammea', id='name-select'),
        html.Div(children=[
            html.Div(children=[
                dcc.Graph(id='Seasonality', figure=draw_figure.season('Acanthis flammea'))
            ], className="col-sm-6"),
            html.Div(children=[
                dcc.Graph(id='Popular', figure=draw_figure.popular('Acanthis flammea'))
            ], className="col-sm-6"),
        ], className="row"),
        html.Div(children=[
            html.Div(children=[
                dcc.Graph(id='History', figure=draw_figure.history('Acanthis flammea'))
            ], className="col-sm-12"),
        ], className="row"),

        html.Div(children=[
            html.H4('Observation Map:'),
            html.Iframe(id="observation-map", srcDoc=draw_figure.map_mark('Acanthis flammea'), width="80%", height="720px")])
    ], id='content')
], id='page')


@app.callback(Output('Seasonality', 'figure'), [Input('name-select', 'value')])
def draw_season(bird_name):
    return draw_figure.season(bird_name)


@app.callback(Output('Popular', 'figure'), [Input('name-select', 'value')])
def draw_popular(bird_name):
    return draw_figure.popular(bird_name)


@app.callback(Output('History', 'figure'), [Input('name-select', 'value')])
def draw_history(bird_name):
    return draw_figure.history(bird_name)


@app.callback(Output('observation-map', 'srcDoc'), [Input('name-select', 'value')])
def draw_map(bird_name):
    return draw_figure.map_mark(bird_name)


if __name__ == '__main__':
    app.run_server()
