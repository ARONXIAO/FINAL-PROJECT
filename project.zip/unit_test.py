# encoding: utf-8
from crawl import *
from draw_figure import *
from data_processing import db_path
import unittest
import sqlite3


class Crawl(unittest.TestCase):
    birds = bird_list()

    def test_bird_list(self):
        self.assertEqual(type(self.birds), list)
        self.assertEqual(type(self.birds[0]), dict)
        self.assertIn('taxon', self.birds[0].keys())

    def test_detail(self):
        detail_ = bird_detail(self.birds[0])
        self.assertEqual(type(detail_), tuple)
        self.assertEqual(len(detail_), 2)
        self.assertEqual(type(detail_[0]), str)
        self.assertEqual(type(detail_[1]), dict)

    def test_stat_data(self):
        data = statistics_data(6930, 'Mallard(Anas platyrhynchos)', False)
        self.assertEqual(len(data), 7)
        self.assertEqual(type(data[0]), str)


class Database(unittest.TestCase):
    db = sqlite3.connect(db_path)
    cur = db.cursor()

    def test_detail_table(self):
        self.cur.execute('select * from detail where ancestor_id = "73041" ')
        result = self.cur.fetchone()
        self.assertEqual(result[2], 'Melozone aberti')
        self.assertEqual(result[4], '48460/1/2/355675/3/7251/559248/9522')

    def test_location_table(self):
        self.cur.execute('select lat, lng from location')
        result = self.cur.fetchone()
        self.assertEqual(len(result), 2)
        self.assertEqual(type(result[0]), float)
        self.assertEqual(type(result[1]), float)


class Draw(unittest.TestCase):
    def test_map(self):
        map_str = map_mark('Melozone aberti')
        self.assertEqual(type(map_str), str)


if __name__ == '__main__':
    unittest.main()
