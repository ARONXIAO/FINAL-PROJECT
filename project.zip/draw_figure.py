# encoding:utf-8
from data_processing import db_path

import plotly.graph_objects as go
import folium

import sqlite3
import json


def birds_list():
    db = sqlite3.connect(db_path)
    cur = db.cursor()
    cur.execute(f'select name from detail')
    result = cur.fetchall()
    options = [{'label': item[0], 'value': item[0]} for item in result]
    return options


def season(name: str):
    try:
        db = sqlite3.connect(db_path)
        cur = db.cursor()
        cur.execute(f'select ancestor_id from detail where name = "{name}" ')
        result = cur.fetchone()
        if result:
            ancestor_id = result[0]
            cur.execute(f'select season_research, season_verifiable from stat_data where ancestor_id = "{ancestor_id}" ')
            season_re, season_ve = cur.fetchone()
            season_re = json.loads(season_re)
            season_ve = json.loads(season_ve)

            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            fig = go.Figure()

            fig.add_trace(go.Scatter(
                x=month, y=season_re, name='Research Grade', line=dict(color='firebrick', width=4, dash='dash'))
            )
            fig.add_trace(go.Scatter(
                x=month, y=season_ve, name='Verifiable', line=dict(color='royalblue', width=4, dash='dash'))
            )
            fig.update_layout(title='Seasonality')
            return fig
    except:
        return None


def history(name: str):
    try:
        db = sqlite3.connect(db_path)
        cur = db.cursor()
        cur.execute(f'select ancestor_id from detail where name = "{name}" ')
        result = cur.fetchone()
        if result:
            ancestor_id = result[0]
            cur.execute(f'select history_research, history_verifiable from stat_data where ancestor_id = "{ancestor_id}" ')
            history_re, history_ve = cur.fetchone()
            history_re = json.loads(history_re)
            history_ve = json.loads(history_ve)

            x = list(history_re.keys())
            y_re = [history_re.get(item) for item in x]
            y_ve = [history_ve.get(item) for item in x]

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=x, y=y_re, name='Research Grade', line=dict(color='firebrick', width=2, dash='dot'))
            )
            fig.add_trace(go.Scatter(
                x=x, y=y_ve, name='Verifiable', line=dict(color='royalblue', width=2, dash='dot'))
            )
            fig.update_layout(title='History')
            return fig
    except:
        return None


def popular(name: str):
    try:
        db = sqlite3.connect(db_path)
        cur = db.cursor()
        cur.execute(f'select ancestor_id from detail where name = "{name}" ')
        result = cur.fetchone()
        if result:
            ancestor_id = result[0]
            cur.execute(f'select popular from stat_data where ancestor_id = "{ancestor_id}" ')
            popular_data = cur.fetchone()
            popular_data = json.loads(popular_data[0])

            fig = go.Figure()

            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            for key, value in popular_data.items():
                y = [value[str(item)] for item in range(1, 13)]
                fig.add_trace(go.Scatter(
                    x=month, y=y, name=key, line=dict(width=2, dash='dot'))
                )
            fig.update_layout(title='Popular')
            return fig
    except:
        return None


def map_mark(name: str):
    try:
        db = sqlite3.connect(db_path)
        cur = db.cursor()
        cur.execute(f'select ancestor_id from detail where name = "{name}" ')
        result = cur.fetchone()
        if result:
            ancestor_id = result[0]
            cur.execute(f'select lat, lng from location where ancestor_id = "{ancestor_id}" ')
            locations = cur.fetchall()

            avg_lat = sum([float(lat) for lat, lng in locations]) / len(locations)
            avg_lng = sum([float(lng) for lat, lng in locations]) / len(locations)

            Map = folium.Map(location=[avg_lat, avg_lng], zoom_start=4)
            for lat, lng in locations:
                folium.Marker(location=[float(lat), float(lng)]).add_to(Map)

            return Map._repr_html_()
    except:
        return None


if __name__ == '__main__':
    map_mark('Acanthis flammea')
